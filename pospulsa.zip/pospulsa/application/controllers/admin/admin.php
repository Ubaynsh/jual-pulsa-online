<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>UBAYDILLAH</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>

	<!-- header -->
		<div class="container">
		</div>
	</div>
	<header>
		<div class="container">
		<h1><a href="index.html"></a>POS PULSA</h1>
		,<ul>
			<li><a href="login.php">MASUK</a></li>
			
		</ul>
	
		</div>
	</header>

	<!-- banner -->
	<section class="banner">
		<h2>WELCOME TO POS PULSA</h2>
	</section>
		</div>
	</section>
	<select><login.php></select>

	<!-- footer -->
	<footer>
		<div class="container">
			<small> Copyright &copy; 2021 - web pro, All Rights Reserved.</small>
		</div>
	</footer>
</body>
</html>
<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		//memanggil function dari MY_Controller
		$this->cekLogin();
		//validasi jika session dengan level karyawan mengakses halaman ini maka akan dialihkan ke halaman karyawan
		if ($this->session->userdata('level') == "karyawan") {
			redirect('karyawan/karyawan');
		}
	}

	public function index(){
		$this->load->view('Admin/Dashboard');

	}
}